var express = require('express');
var app = express();

app.get('/', function (req, res){
    res.send('web inicial de mi API')
});

app.get('/saludo', function (req, res){
    res.send('hola mundo')
});

app.get('/despedida', function (req, res){
    res.send('Adiós Mundo Cruel')
});

app.listen(3000, function(){
    console.log('Aplicación de ejemplo , escuchando en el puerto 3000')
});