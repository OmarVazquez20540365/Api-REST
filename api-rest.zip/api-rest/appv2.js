//paquetes requeridos y puerto
const express = require('express');
const port = 3002;
//permite el manejo de post y put
const bodyParser = require('body-parser')
const routes  = require('./routes/routes')
const app = express();
//usar node.js bosyparser middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true,
}));
routes(app);
//iniciar el servidor
const server = app.listen(port, (error) => {
    if (error) return console.log(`error: ${error}`);
    console.log(`El Servidor escucha en el puerto ${server.address().port}`);
});