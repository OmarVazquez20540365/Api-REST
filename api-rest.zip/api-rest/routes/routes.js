//CARGAR LA CONEXION DE GRUPO MYSQL
const pool  = require ('../data/config');
//RUTA DE LA APP
const router = app=>{
    app.get('/', (request, response) => {
        response.send({
            //MUESTRA EL MENSAJE DE BIENVENIDA
            message: 'bienvenido a node.js Express REST API'
        });
    });

//MOSTRAR A TODOS LOS USUARIOS
app.get('/users', (request, response) => {
    pool.query('SELECT * FROM users', (error, result)=>{
        if (error) throw error;
        response.send(result);
    });
});

//MOSTRAR EL USUARIO SOLO POR EL ID
app.get('/users/:id',(request, response)=>{
    const id = request.params.id;

    pool.query('SELECT * FROM users WHERE id = ?', id , (error, result) => {
        if (error) throw error;
        response.send(reslut);
    });
});

// AGREGAR UN NUEVO USUARIO
app.post('/users', (request, response) => {
    pool.query('INSERT INTO users SET ?', request.body, (error, result) => {
        if (error) throw error;
        response.status(201).send(`User Added with ID: ${result.insertId}`);
    });
} );

//ACTUALIZAR EL USUARIO EXISTENTE
app.put('/users/:id', (request , response) => {
    const id = request.params.id;
    pool.query('UPDATE users SET ? WHERE id  = ?', [request.body, id], (error, result) => {
        if(error) throw error;

        response.send('user updated successfully.');
    });
} );

//ELIMINAR EL USUARIO
app.delete('/users/:id', (request , response) => {
    const id = request.params.id;
    pool.query('DELETE FROM users WHERE id  = ? ' , id, (error, result) => {
        if (error) throw error;
        response.send('User Terminated');
    });
}); 
}
//EXPORTAR EL ROUTER
module.exports = router;